// Uncomment the next line to use precompiled headers
#include "pch.h"
// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

//
// the global test environment setup and tear down
// you should not need to change anything here
//
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        // initialize random seed
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart pointer to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        // erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

//
// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::SetUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
//
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created?
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

//
// Test that a collection is empty when created.
//
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0u);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 // TEST_F(CollectionTest, AlwaysFail)
 // {
 //   FAIL();
 // }

 //
 // TODO: Create a test to verify adding a single value to an empty collection
 //
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // confirm it's empty initially
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    // add exactly one entry
    add_entries(1);

    // after adding one element, it should no longer be empty and size must be 1
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1u);
}

//
// TODO: Create a test to verify adding five values to collection
//
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // start empty
    ASSERT_TRUE(collection->empty());

    // add five entries
    add_entries(5);

    // size must be exactly 5
    ASSERT_EQ(collection->size(), 5u);
}

//
// TODO: Create a test to verify that max_size is greater than or equal to size for 0, 1, 5, 10 entries
//
TEST_F(CollectionTest, MaxSizeGreaterOrEqualSize)
{
    // For 0 entries
    ASSERT_EQ(collection->size(), 0u);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1u);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 5 entries (add 4 more to total 5)
    add_entries(4);
    ASSERT_EQ(collection->size(), 5u);
    ASSERT_GE(collection->max_size(), collection->size());

    // For 10 entries (add 5 more to total 10)
    add_entries(5);
    ASSERT_EQ(collection->size(), 10u);
    ASSERT_GE(collection->max_size(), collection->size());
}

//
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
//
TEST_F(CollectionTest, CapacityGreaterOrEqualSize)
{
    // For 0 entries
    ASSERT_EQ(collection->size(), 0u);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1u);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 5 entries (add 4 more to total 5)
    add_entries(4);
    ASSERT_EQ(collection->size(), 5u);
    ASSERT_GE(collection->capacity(), collection->size());

    // For 10 entries (add 5 more to total 10)
    add_entries(5);
    ASSERT_EQ(collection->size(), 10u);
    ASSERT_GE(collection->capacity(), collection->size());
}

//
// TODO: Create a test to verify resizing increases the collection
//
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    // start empty
    ASSERT_EQ(collection->size(), 0u);

    // resize to 5 - new ints should be value-initialized to 0
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5u);

    // check that newly added slots are zero
    for (size_t i = 0; i < collection->size(); ++i)
    {
        ASSERT_EQ(collection->at(i), 0);
    }
}

//
// TODO: Create a test to verify resizing decreases the collection
//
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    // add 10 random entries
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    // resize down to 5
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5u);

    // The first 5 elements should still exist (we won't check values specifically because they are random)
}

//
// TODO: Create a test to verify resizing decreases the collection to zero
//
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
    // add 5 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    // resize down to 0
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0u);
    ASSERT_TRUE(collection->empty());
}

//
// TODO: Create a test to verify clear erases the collection
//
TEST_F(CollectionTest, ClearErasesCollection)
{
    // add 5 entries
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    // clear the entire collection
    collection->clear();
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

//
// TODO: Create a test to verify erase(begin, end) erases the collection
//
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    // add 5 entries
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    // erase all elements via erase(begin, end)
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);
}

//
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
//
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    // add 5 entries
    add_entries(5);
    size_t oldSize = collection->size();
    size_t oldCapacity = collection->capacity();

    // reserve more than current capacity
    collection->reserve(oldCapacity + 10);
    ASSERT_GE(collection->capacity(), oldCapacity + 10);
    // size must remain unchanged
    ASSERT_EQ(collection->size(), oldSize);
}

//
// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
//
TEST_F(CollectionTest, AtOutOfRangeThrows)
{
    // add 5 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    // valid indices: 0 through 4. Accessing index==5 should throw std::out_of_range
    EXPECT_THROW(collection->at(5), std::out_of_range);

    // also test on empty collection: accessing at(0) should throw
    collection->clear();
    ASSERT_TRUE(collection->empty());
    EXPECT_THROW(collection->at(0), std::out_of_range);
}

//
// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
//

// Custom Positive Test: verify that push_back(value) stores the correct value at index 0
TEST_F(CollectionTest, PushBackStoresCorrectValue)
{
    // collection is empty initially
    ASSERT_TRUE(collection->empty());

    // manually push back a known value
    collection->push_back(42);
    ASSERT_EQ(collection->size(), 1u);
    // at(0) must equal 42
    ASSERT_EQ(collection->at(0), 42);
}

// Custom Negative Test: verify that reserve beyond max_size throws std::length_error
TEST_F(CollectionTest, ReserveBeyondMaxSizeThrows)
{
    // attempting to reserve more than max_size should throw length_error
    EXPECT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}
