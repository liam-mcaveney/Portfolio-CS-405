﻿#include <iostream>
#include <string>
#include <cstring>    // for strncpy_s

int main() {
    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    std::cout << "Enter a value: ";
    std::string temp_input;
    std::getline(std::cin, temp_input);

    if (temp_input.length() >= sizeof(user_input)) {
        std::cout << "Error: Input too long! Maximum is "
            << (sizeof(user_input) - 1) << " characters.\n";
        // optional: truncate for logging, but strncpy_s with _TRUNCATE does it for you
        temp_input.resize(sizeof(user_input) - 1);
    }

    // Use strncpy_s: last parameter _TRUNCATE means "copy up to buffer-1 and null-terminate"
    errno_t err = strncpy_s(
        user_input,                   // dest buffer
        sizeof(user_input),           // size of dest buffer
        temp_input.c_str(),           // source C-string
        _TRUNCATE                     // truncate if source ≥ dest
    );

    if (err != 0) {
        std::cerr << "strncpy_s failed with code " << err << "\n";
        return 1;
    }

    std::cout << "You entered: " << user_input << "\n"
        << "Account Number = " << account_number << "\n";

    return 0;
}
