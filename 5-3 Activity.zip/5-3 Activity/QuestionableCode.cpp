﻿// QuestionableCode.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <cassert>
#include <iostream>
#include <numeric>
#include <set>
#include <vector>


class C
{
    std::set<int> typedefs;

public:
    // Fix #1: Endless recursion → return true when found
    bool is_type(int type) const
    {
        if (typedefs.find(type) != typedefs.end())
            return true;
        return false;
    }
};

class A
{
    int x;

public:
    // Fix #2: Private copy constructor should be =delete if copying is disallowed
    A(const A& other) = delete;
    A(int val) : x(val) {}
};

class MySpecialType
{
public:
    int MyVal = 1;

    // Fix #3: Removed noexcept to allow throwing (or could remove throw)
    void DontThrow()
    {
        throw "Ha! I threw anyway!";
    }
};

void foo(int** a)
{
    // Fix #4: Allocate on heap instead of pointing into a local stack variable
    int* b = new int(1);
    *a = b;
}

void work_with_arrays(int count)
{
    int buf[10];
    // Fix #5: Only index valid range [0..9]
    if (count >= 0 && count < 10)
    {
        buf[count] = 0;
    }
    else
    {
        // out of range: do nothing or handle error
    }
}

void do_something_useless()
{
    int sum = 0;
    for (auto i = 0; i < 1000; ++i)
    {
        sum += i;
    }

    std::cout << "I summed up " << sum << " as the answer." << std::endl;
}

void vector_test()
{
    std::vector<int> items;
    items.push_back(1);
    items.push_back(2);
    items.push_back(3);

    // Fix #6: Use erase-return idiom to avoid invalidating iterator
    for (auto iter = items.begin(); iter != items.end();)
    {
        if (*iter == 2)
        {
            iter = items.erase(iter);
        }
        else
        {
            ++iter;
        }
    }
}

int a;

// Fix #7: Changed return type to int to avoid implicit conversion
int my_function()
{
    a = 1 + 2;
    return a;
}

struct Token
{
    Token* next() { return nullptr; }
};

int foo(Token* tok)
{
    // Fix #8: Advance tok inside loop to avoid infinite spin
    while (tok)
    {
        tok = tok->next();
    }

    return 0;
}

int main()
{
    std::vector<int> counts{ 1, 2, 3, 5 };
    int x = 0;
    int y = 0;
    int z = 0;

    std::cout << "Welcome to the Questionable Code Test!" << std::endl;

    //do_something_useless();

    work_with_arrays(10);

    // Fix #9: Use comparison instead of assignment in assert
    z = 2;
    assert(z == 2);

    // Now my_function() returns int, so compare to 3 explicitly
    assert(my_function() == 3);

    try
    {
        int x_inner = 5;
        int y_inner = 5;
        int z_inner = 5;
        std::cout << "x_inner + y_inner + z_inner = "
            << (x_inner + y_inner + z_inner) << std::endl;
    }
    catch (...)
    {
        // no action
    }

    int* c = nullptr;
    foo(&c);
    // Clean up heap allocation from foo(int**)
    delete c;
    c = nullptr;

    vector_test();

    MySpecialType myobject;
    std::cout << "myobject.MyVal = " << myobject.MyVal << std::endl;

    return 0;
}
