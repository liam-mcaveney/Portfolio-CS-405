// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    explicit CustomException(const std::string& msg)
        : message_(msg) {
    }  // store user-provided message
    const char* what() const noexcept override {
        return message_.c_str();
    }
private:
    std::string message_;
};

bool do_even_more_custom_application_logic()
{
    // Throw a standard exception to signal an error in this deeper logic
    throw std::runtime_error("Error in even more custom application logic");
    // (unreachable) std::cout << "Running Even More Custom Application Logic.\n";
    return true;
}

void do_custom_application_logic()
{
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrap the deeper logic call in a try/catch for std::exception
    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e) {
        // Display the caught exception message, then continue
        std::cerr << "Caught standard exception in custom logic: " << e.what() << std::endl;
    }

    // Now signal a higher-level error with our own custom exception
    throw CustomException("Custom application logic failure");
    // (unreachable) std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // Guard against divide-by-zero using a standard C++ exception
    if (den == 0.0f) {
        throw std::invalid_argument("Division by zero");
    }
    return num / den;
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0.0f;

    // Only catch the exception thrown by divide(); prevent propagation
    try {
        float result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Error during division: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Wrap the entire workflow in handlers in this order:
    // 1. CustomException
    // 2. std::exception
    // 3. catch-all
    try {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& ce) {
        std::cerr << "Caught custom exception in main: " << ce.what() << std::endl;
    }
    catch (const std::exception& e) {
        std::cerr << "Caught standard exception in main: " << e.what() << std::endl;
    }
    catch (...) {
        std::cerr << "Caught unknown exception in main." << std::endl;
    }

    return 0;
}
