﻿// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <ctime>

// Forward declarations
std::string encrypt_decrypt(const std::string& source, const std::string& key);
std::string read_file(const std::string& filename);
void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& string_data);
std::string get_student_name(const std::string& string_data);
std::string get_key(const std::string& string_data);
std::string get_payload(const std::string& string_data);

int main()
{
    // File names (as defined by the starter code).
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    // 1. Load entire input file into memory
    const std::string file_contents = read_file(file_name);

    // 2. Extract student name, key, and raw payload
    const std::string student_name = get_student_name(file_contents);
    const std::string key = get_key(file_contents);
    const std::string payload = get_payload(file_contents);

    // 3. Perform XOR encryption on payload
    const std::string encrypted_string = encrypt_decrypt(payload, key);

    // 4. Save encrypted data (student_name, key, encrypted_payload)
    save_data_file(encrypted_file_name,
        student_name,
        key,
        encrypted_string);

    // 5. Decrypt the encrypted string (XOR again with same key)
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // 6. Save decrypted data (student_name, key, decrypted_payload)
    save_data_file(decrypted_file_name,
        student_name,
        key,
        decrypted_string);

    std::cout << "Read File: " << file_name
        << "  - Encrypted To: " << encrypted_file_name
        << "  - Decrypted To: " << decrypted_file_name
        << std::endl;

    return 0;
}


/// <summary>
/// Performs XOR on each character of 'source' with the corresponding character of 'key'.
/// If 'key' is shorter, it wraps around via modulo arithmetic.
/// </summary>
/// <param name="source">Input string to encrypt/decrypt</param>
/// <param name="key">XOR key</param>
/// <returns>Transformed string (encrypted or decrypted)</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    assert(!key.empty() && "Key must not be empty");

    std::string result;
    result.reserve(source.size());

    const size_t key_length = key.length();
    for (size_t i = 0; i < source.size(); ++i)
    {
        // XOR the i-th character of source with the (i % key_length)-th character of key.
        char encrypted_char = static_cast<char>(source[i] ^ key[i % key_length]);
        result.push_back(encrypted_char);
    }

    return result;
}


/// <summary>
/// Reads an entire text file into a single string (including newlines).
/// </summary>
/// <param name="filename">Name of the file to read</param>
/// <returns>All file contents as one string</returns>
std::string read_file(const std::string& filename)
{
    std::ifstream in(filename, std::ios::binary);
    if (!in)
    {
        std::cerr << "ERROR: Could not open input file: " << filename << std::endl;
        std::exit(EXIT_FAILURE);
    }

    std::ostringstream buffer;
    buffer << in.rdbuf();
    return buffer.str();
}


/// <summary>
/// Extracts the student name from the file's contents.
/// Everything before the first newline is considered the student name.
/// </summary>
/// <param name="string_data">Entire contents of the input file</param>
/// <returns>Student name (first line)</returns>
std::string get_student_name(const std::string& string_data)
{
    size_t pos = string_data.find('\n');
    if (pos == std::string::npos)
    {
        // If there's no newline, the file is malformed.
        std::cerr << "ERROR: Input file missing student name line." << std::endl;
        std::exit(EXIT_FAILURE);
    }
    return string_data.substr(0, pos);
}


/// <summary>
/// Extracts the key from the file's contents.
/// The key is the second line: from just after the first newline, up to the second newline. 
/// </summary>
/// <param name="string_data">Entire contents of the input file</param>
/// <returns>Key (second line)</returns>
std::string get_key(const std::string& string_data)
{
    size_t first_newline = string_data.find('\n');
    if (first_newline == std::string::npos)
    {
        std::cerr << "ERROR: Input file missing student name line." << std::endl;
        std::exit(EXIT_FAILURE);
    }

    size_t second_newline = string_data.find('\n', first_newline + 1);
    if (second_newline == std::string::npos)
    {
        std::cerr << "ERROR: Input file missing key line." << std::endl;
        std::exit(EXIT_FAILURE);
    }

    // Key starts just after first_newline and goes up to (but not including) second_newline
    return string_data.substr(first_newline + 1, second_newline - (first_newline + 1));
}


/// <summary>
/// Extracts everything after the second newline as the “payload.”
/// </summary>
/// <param name="string_data">Entire contents of the input file</param>
/// <returns>Payload (everything after line 2)</returns>
std::string get_payload(const std::string& string_data)
{
    size_t first_newline = string_data.find('\n');
    size_t second_newline = string_data.find('\n', first_newline + 1);
    if (second_newline == std::string::npos)
    {
        // If there's no second newline, no actual payload exists
        return "";
    }

    // Payload begins right after the second newline
    return string_data.substr(second_newline + 1);
}


/// <summary>
/// Writes a file in the required three‐part format:
///   1. student_name + newline  
///   2. key + newline  
///   3. string_data (the encrypted or decrypted payload)  
/// </summary>
/// <param name="filename">Where to write</param>
/// <param name="student_name">First line</param>
/// <param name="key">Second line</param>
/// <param name="string_data">Text payload (can be multiple lines)</param>
void save_data_file(const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& string_data)
{
    std::ofstream out(filename, std::ios::binary);
    if (!out)
    {
        std::cerr << "ERROR: Could not open output file: " << filename << std::endl;
        std::exit(EXIT_FAILURE);
    }

    // Write student name, then newline
    out << student_name << '\n';

    // Write key, then newline
    out << key << '\n';

    // Write the encrypted or decrypted payload
    out << string_data;
}
